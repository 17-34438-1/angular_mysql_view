import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-export-container-baylist',
  templateUrl: './export-container-baylist.component.html',
  styleUrls: ['./export-container-baylist.component.css']
})
export class ExportContainerBaylistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
